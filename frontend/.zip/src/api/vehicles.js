import api from './auth';

export const createVehicle = async (vehicleData) => {
  const response = await api.post('/vehicles', vehicleData);
  return response.data;
};

export const getVehicles = async () => {
  const response = await api.get('/vehicles');
  return response.data;
};

export const getVehicleById = async (id) => {
  const response = await api.get(`/vehicles/${id}`);
  return response.data;
};

export const updateSecurityCheck = async (id, checkData) => {
  const response = await api.put(`/vehicles/${id}/security-check`, checkData);
  return response.data;
};

export const checkOutVehicle = async (id) => {
  const response = await api.put(`/vehicles/${id}/checkout`);
  return response.data;
};

export const getVendorAndProductsByPO = async (poNumber) => {
  const response = await api.get(`/vehicles/po/${poNumber}`);
  return response.data;
};