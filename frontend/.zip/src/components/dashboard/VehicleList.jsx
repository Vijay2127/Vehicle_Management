import { useState, useEffect } from 'react';
import {
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Typography,
  Button,
  Chip,
  Box,
  CircularProgress,
} from '@mui/material';
import { getVehicles } from '../../api/vehicles';
import { format } from 'date-fns';

const statusColors = {
  pending: 'default',
  approved: 'success',
  rejected: 'error',
};

const VehicleList = () => {
  const [vehicles, setVehicles] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const fetchVehicles = async () => {
    try {
      setLoading(true);
      const data = await getVehicles();
      setVehicles(data);
      setError(null);
    } catch (err) {
      setError('Error fetching vehicles');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchVehicles();
  }, []);

  if (loading) return <CircularProgress />;
  if (error) return <Typography color="error">{error}</Typography>;

  return (
    <Paper elevation={3} sx={{ p: 3 }}>
      <Typography variant="h6" gutterBottom>
        Vehicle List
      </Typography>
      <TableContainer component={Paper}>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>Vehicle Number</TableCell>
              <TableCell>D.C. Number</TableCell>
              <TableCell>P.O. Number</TableCell>
              <TableCell>Entry Time</TableCell>
              <TableCell>Security Check</TableCell>
              <TableCell>Status</TableCell>
              <TableCell>Actions</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {vehicles.map((vehicle) => (
              <TableRow key={vehicle._id}>
                <TableCell>{vehicle.vehicleNumber}</TableCell>
                <TableCell>{vehicle.dcNumber}</TableCell>
                <TableCell>{vehicle.poNumber}</TableCell>
                <TableCell>
                  {format(new Date(vehicle.entryTime), 'dd/MM/yyyy HH:mm')}
                </TableCell>
                <TableCell>
                  <Chip
                    label={vehicle.securityCheck.status}
                    color={statusColors[vehicle.securityCheck.status]}
                  />
                </TableCell>
                <TableCell>
                  {vehicle.isCheckedOut ? (
                    <Chip label="Checked Out" color="success" />
                  ) : (
                    <Chip label="In Facility" color="info" />
                  )}
                </TableCell>
                <TableCell>
                  <Button size="small">View</Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>
    </Paper>
  );
};

export default VehicleList;