import { useState, useEffect } from 'react';
import {
  TextField,
  Button,
  Box,
  Typography,
  Paper,
  Grid,
  CircularProgress,
} from '@mui/material';
import { createVehicle, getVendorAndProductsByPO } from '../../api/vehicles';

const VehicleForm = ({ onSuccess }) => {
  const [formData, setFormData] = useState({
    vehicleNumber: '',
    dcNumber: '',
    poNumber: '',
    photo: '',
  });

  const [vendorDetails, setVendorDetails] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handlePOBlur = async () => {
    if (!formData.poNumber) return;
    try {
      setLoading(true);
      const data = await getVendorAndProductsByPO(formData.poNumber);
      setVendorDetails(data);
      setError(null);
    } catch (err) {
      setError('No vendor found with this PO number');
      setVendorDetails(null);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      setLoading(true);
      await createVehicle(formData);
      setError(null);
      onSuccess();
      setFormData({
        vehicleNumber: '',
        dcNumber: '',
        poNumber: '',
        photo: '',
      });
      setVendorDetails(null);
    } catch (err) {
      setError(err.response?.data?.msg || 'Error creating vehicle');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Paper elevation={3} sx={{ p: 3, mb: 3 }}>
      <Typography variant="h6" gutterBottom>
        Add New Vehicle
      </Typography>
      {error && (
        <Typography color="error" sx={{ mb: 2 }}>
          {error}
        </Typography>
      )}
      <form onSubmit={handleSubmit}>
        <Grid container spacing={2}>
          <Grid item xs={12} sm={6}>
            <TextField
              fullWidth
              margin="normal"
              label="Vehicle Number"
              name="vehicleNumber"
              value={formData.vehicleNumber}
              onChange={handleChange}
              required
            />
          </Grid>
          <Grid item xs={12} sm={6}>
            <TextField
              fullWidth
              margin="normal"
              label="D.C. Number"
              name="dcNumber"
              value={formData.dcNumber}
              onChange={handleChange}
              required
            />
          </Grid>
          <Grid item xs={12} sm={6}>
            <TextField
              fullWidth
              margin="normal"
              label="P.O. Number"
              name="poNumber"
              value={formData.poNumber}
              onChange={handleChange}
              onBlur={handlePOBlur}
              required
            />
          </Grid>
          <Grid item xs={12} sm={6}>
            <TextField
              fullWidth
              margin="normal"
              label="Photo URL"
              name="photo"
              value={formData.photo}
              onChange={handleChange}
            />
          </Grid>
        </Grid>
        {loading && <CircularProgress sx={{ mt: 2 }} />}
        <Button
          type="submit"
          variant="contained"
          disabled={loading}
          sx={{ mt: 2 }}
        >
          Submit
        </Button>
      </form>

      {vendorDetails && (
        <Box sx={{ mt: 3 }}>
          <Typography variant="h6" gutterBottom>
            Vendor Details
          </Typography>
          <Typography>
            <strong>Vendor Name:</strong> {vendorDetails.vendor.name}
          </Typography>
          <Typography>
            <strong>Company Name:</strong> {vendorDetails.vendor.companyName}
          </Typography>
          <Typography>
            <strong>P.O. Number:</strong> {vendorDetails.poNumber}
          </Typography>
          <Typography variant="h6" sx={{ mt: 2 }} gutterBottom>
            Products
          </Typography>
          {vendorDetails.products.map((product) => (
            <Box key={product._id} sx={{ mb: 1 }}>
              <Typography>
                <strong>Name:</strong> {product.name}
              </Typography>
              <Typography>
                <strong>Quantity:</strong> {product.quantity}
              </Typography>
              {product.description && (
                <Typography>
                  <strong>Description:</strong> {product.description}
                </Typography>
              )}
            </Box>
          ))}
        </Box>
      )}
    </Paper>
  );
};

export default VehicleForm;