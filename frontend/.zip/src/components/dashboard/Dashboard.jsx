import { Typography, Box } from '@mui/material';
import { useContext } from 'react';
import AuthContext from '../../context/AuthContext';

const Dashboard = () => {
  const { user } = useContext(AuthContext);
  console.log('User data:', user); // Add this line
  return (
    <Box>
      <Typography variant="h4" gutterBottom>
        Dashboard
      </Typography>
      <Typography variant="body1">
        Welcome, {user?.username} ({user?.role})
      </Typography>
    </Box>
  );
};

export default Dashboard;