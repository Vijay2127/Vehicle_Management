import { useState, useEffect } from 'react';
import {
  TextField,
  Button,
  Box,
  Typography,
  Paper,
  MenuItem,
  CircularProgress,
} from '@mui/material';
import { updateSecurityCheck } from '../../api/vehicles';

const SecurityCheck = ({ vehicleId, currentStatus, onSuccess }) => {
  const [formData, setFormData] = useState({
    status: currentStatus || 'pending',
    remarks: '',
  });

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      setLoading(true);
      await updateSecurityCheck(vehicleId, formData);
      setError(null);
      onSuccess();
    } catch (err) {
      setError(err.response?.data?.msg || 'Error updating security check');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Paper elevation={3} sx={{ p: 3, mt: 3 }}>
      <Typography variant="h6" gutterBottom>
        Security Check
      </Typography>
      {error && (
        <Typography color="error" sx={{ mb: 2 }}>
          {error}
        </Typography>
      )}
      <form onSubmit={handleSubmit}>
        <TextField
          select
          fullWidth
          margin="normal"
          label="Status"
          name="status"
          value={formData.status}
          onChange={handleChange}
          required
        >
          <MenuItem value="pending">Pending</MenuItem>
          <MenuItem value="approved">Approved</MenuItem>
          <MenuItem value="rejected">Rejected</MenuItem>
        </TextField>
        <TextField
          fullWidth
          margin="normal"
          label="Remarks"
          name="remarks"
          value={formData.remarks}
          onChange={handleChange}
          multiline
          rows={3}
        />
        {loading && <CircularProgress sx={{ mt: 2 }} />}
        <Button
          type="submit"
          variant="contained"
          disabled={loading}
          sx={{ mt: 2 }}
        >
          Update Security Check
        </Button>
      </form>
    </Paper>
  );
};

export default SecurityCheck;