import { useState, useContext } from 'react';
import { TextField, Button, Box, Typography, Paper } from '@mui/material';
import AuthContext from '../../context/AuthContext';
import { useNavigate } from 'react-router-dom';

const Login = () => {
  const [formData, setFormData] = useState({
    username: '',
    password: '',
  });

  const { login, error } = useContext(AuthContext);
  const navigate = useNavigate();

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
login(formData.username, formData.password);
};

return (
<Box
sx={{
display: 'flex',
justifyContent: 'center',
alignItems: 'center',
minHeight: '80vh',
}}
>
<Paper elevation={3} sx={{ p: 4, width: '100%', maxWidth: 400 }}>
<Typography variant="h5" component="h1" gutterBottom>
Login
</Typography>
{error && (
<Typography color="error" sx={{ mb: 2 }}>
{error}
</Typography>
)}
<form onSubmit={handleSubmit}>
<TextField fullWidth margin="normal" label="Username" name="username" value={formData.username} onChange={handleChange} required />
<TextField fullWidth margin="normal" label="Password" name="password" type="password" value={formData.password} onChange={handleChange} required />
<Button
type="submit"
variant="contained"
fullWidth
sx={{ mt: 3, mb: 2 }}
>
Login
</Button>
</form>
<Typography variant="body2">
Don't have an account?{' '}
<Button onClick={() => navigate('/register')}>Register</Button>
</Typography>
</Paper>
</Box>
);
};

export default Login;