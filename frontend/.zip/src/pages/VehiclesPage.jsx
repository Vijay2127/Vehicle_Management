import { useState } from 'react';
import { Box } from '@mui/material';
import VehicleForm from '../components/dashboard/VehicleForm';
import VehicleList from '../components/dashboard/VehicleList';

const VehiclesPage = () => {
  const [refresh, setRefresh] = useState(false);

  const handleSuccess = () => {
    setRefresh(!refresh);
  };

  return (
    <Box>
      <VehicleForm onSuccess={handleSuccess} />
      <VehicleList key={refresh} />
    </Box>
  );
};

export default VehiclesPage;